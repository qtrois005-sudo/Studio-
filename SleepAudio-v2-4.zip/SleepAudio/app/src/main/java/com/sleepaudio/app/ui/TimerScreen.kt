package com.sleepaudio.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sleepaudio.app.data.FadeOutOption
import com.sleepaudio.app.player.PlayerState
import com.sleepaudio.app.util.TimeUtils

/**
 * Écran minuterie volontairement simple, sur demande explicite : uniquement
 * "Arrêter dans..." (heures/minutes) + Démarrer. Le mode "heure précise" et
 * le fondu de fin restent supportés côté logique (SleepTimerManager,
 * FadeOutOption) mais ne sont plus exposés dans cette UI.
 */
@Composable
fun TimerScreen(
    state: PlayerState,
    onBack: () -> Unit,
    onStartDuration: (Int, Int, Int, FadeOutOption) -> Unit,
    onCancelTimer: () -> Unit
) {
    var hours by remember { mutableStateOf("0") }
    var minutes by remember { mutableStateOf("30") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Lecteur") }

        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Filled.Bedtime,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(start = 8.dp))
            Text("Minuterie de sommeil", style = MaterialTheme.typography.headlineSmall)
        }

        SectionCard(title = "Arrêter dans...") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = hours,
                    onValueChange = { hours = it.filter { c -> c.isDigit() } },
                    label = { Text("Heures") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = minutes,
                    onValueChange = { minutes = it.filter { c -> c.isDigit() } },
                    label = { Text("Minutes") },
                    modifier = Modifier.weight(1f)
                )
            }

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(top = 12.dp))

            PrimaryButton(text = "Démarrer") {
                onStartDuration(
                    hours.toIntOrNull() ?: 0,
                    minutes.toIntOrNull() ?: 0,
                    0,
                    FadeOutOption.NONE
                )
            }

            // Retour visuel immédiat dès que la minuterie est active :
            // confirme que le démarrage a bien été pris en compte et affiche
            // le compte à rebours qui bouge en temps réel.
            AnimatedVisibility(visible = state.timer.isActive) {
                Column {
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(top = 12.dp))
                    Text(
                        text = "✓ Minuterie démarrée",
                        color = MaterialTheme.colorScheme.secondary,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Text(
                        text = "Arrêt dans " + TimeUtils.formatDuration(state.timer.liveRemainingMillis),
                        style = MaterialTheme.typography.headlineSmall
                    )
                }
            }
        }

        if (state.timer.isActive) {
            TextButton(onClick = onCancelTimer, modifier = Modifier.fillMaxWidth()) {
                Text("Annuler la minuterie")
            }
        }
    }
}
