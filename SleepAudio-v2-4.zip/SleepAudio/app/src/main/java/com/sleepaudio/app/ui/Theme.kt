package com.sleepaudio.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Palette calme, profonde, pensée pour une utilisation nocturne — inspirée
// d'un ciel étoilé : navy profond, indigo lumineux, or doux pour les accents.
private val DeepNavy = Color(0xFF0B0F1A)
private val Surface1 = Color(0xFF171F30)
private val Surface2 = Color(0xFF1F2A42)
private val AccentIndigo = Color(0xFF7C8CFF)
private val AccentSoftGold = Color(0xFFE8C77E)
private val TextPrimary = Color(0xFFF3F5FA)
private val TextSecondary = Color(0xFFAAB3CC)

private val DarkColors = darkColorScheme(
    primary = AccentIndigo,
    secondary = AccentSoftGold,
    background = DeepNavy,
    surface = Surface1,
    surfaceVariant = Surface2,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    error = Color(0xFFFF8A80)
)

private val LightColors = lightColorScheme(
    primary = AccentIndigo,
    secondary = AccentSoftGold
)

// Formes largement arrondies : lignes douces, adaptées à une app "confort".
private val AppShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 24.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp)
)

@Composable
fun SleepAudioTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        shapes = AppShapes,
        typography = AppTypography,
        content = content
    )
}
